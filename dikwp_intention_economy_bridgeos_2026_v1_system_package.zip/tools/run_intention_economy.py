#!/usr/bin/env python3
"""Offline CLI for DIKWP Intention Economy BridgeOS 2026 V1."""
from __future__ import annotations
import argparse,json
from pathlib import Path
from datetime import datetime, timezone

def score_case(case):
    risk = float(case.get('risk',50))
    value = float(case.get('value',70))
    # heuristic: value reduced by excessive risk, but high audit can recover
    intent_fit = max(0,min(100,value - max(0,risk-50)*0.45))
    agency = 100 if 'confirm' in case.get('p_contract','').lower() or '确认' in case.get('p_contract','') else 65
    return {'intent_fit':round(intent_fit,1),'user_agency':agency,'risk_discount':risk,'passport_readiness':round((intent_fit+agency+(100-risk))/3,1)}

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('case_json', type=Path)
    ap.add_argument('--out', type=Path, default=Path('outputs'))
    args=ap.parse_args()
    case=json.loads(args.case_json.read_text(encoding='utf-8'))
    scores=score_case(case)
    passport={'version':'DIKWP Intention Economy BridgeOS 2026 V1 CLI','generated_at':datetime.now(timezone.utc).isoformat(),'case':case,'scores':scores,'boundaries':{'no_real_payment':True,'no_auto_purchase':True,'human_gate_required':True,'synthetic_or_authorized_data_only':True}}
    args.out.mkdir(parents=True,exist_ok=True)
    target=args.out/(case.get('id','intent_case')+'_intent_passport.json')
    target.write_text(json.dumps(passport,ensure_ascii=False,indent=2),encoding='utf-8')
    print('Output:',target)
    print('Scores:',scores)
if __name__=='__main__': main()
