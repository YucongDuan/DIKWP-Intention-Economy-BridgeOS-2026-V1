#!/usr/bin/env python3
"""Lightweight static boundary audit for the open package; not a security certification."""
from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parents[1]
PATTERNS=[(r'\brequests\.', 'network requests'),(r'\burllib\.request','URL access'),(r'\bsocket\.','raw socket'),(r'\beval\(','dynamic eval'),(r'\bexec\(','dynamic exec'),(r'localStorage','browser local storage'),(r'navigator\.geolocation|camera|microphone','sensor access')]
EXCLUDE={'static_boundary_audit.py','static_boundary_audit_report.json','README.md','GOVERNANCE.md','SOURCES.md'}
def main():
    findings=[]
    for p in ROOT.rglob('*'):
        if not p.is_file() or p.name in EXCLUDE or p.suffix.lower() not in {'.py','.html','.js','.json'}: continue
        text=p.read_text(encoding='utf-8',errors='ignore')
        for pat,meaning in PATTERNS:
            if re.search(pat,text,re.I): findings.append({'file':str(p.relative_to(ROOT)),'meaning':meaning})
    result={'package':'DIKWP Intention Economy BridgeOS 2026 V1','findings':findings,'network_or_payment_capability_detected':bool(findings),'note':'No real commerce, payment, browser storage, ad-serving, or production-action adapters are included.'}
    (ROOT/'static_boundary_audit_report.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))
if __name__=='__main__': main()
