# 30-Day Pilot Plan

## Week 1: Problem and boundary
- select one low-risk domain: course selection, travel planning, public-service navigation, or product comparison
- define legal and illegal intent registry
- define user-visible Intent Contract
- create synthetic or authorized data assets

## Week 2: DIKWP content and intent graph
- compile attention signals into DIKWP content cards
- register stakeholders and their intent vectors
- build content-intent semantic edges
- define sponsored content and commission disclosure fields

## Week 3: Matching, routing, and action gates
- run offer matching with evidence and residuals
- test dark-pattern and manipulation probes
- require human gate before any high-impact action
- record IntentTrace and outcome ledger

## Week 4: Audit and release
- run simulations: hidden sponsorship, child user, high-impact health/finance, purpose drift, unclear data rights
- export Intent Passport
- conduct legal, privacy, UX, and user-rights review
- decide continue/revise/stop
