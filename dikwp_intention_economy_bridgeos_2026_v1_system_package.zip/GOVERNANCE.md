# Governance and Safety Boundary

## Prohibited uses
- hidden ad injection or sponsored ranking without disclosure
- autonomous payment, purchase, subscription, booking, account creation, or signing
- manipulating children, older adults, patients, or vulnerable users
- inferring sensitive traits for targeting without authorization
- using intent data for unrelated AI training without explicit consent
- dark patterns, scarcity pressure, fear-based conversion, or hidden commissions
- bypassing official services, legal rules, platform policies, or public-interest safeguards

## Required controls
- user-visible Intent Contract
- allowed and forbidden uses
- data minimization
- sponsored-content disclosure
- action gates for high-impact actions
- revocation and deletion path
- evidence ledger
- audit log
- human review for sensitive domains
- kill conditions and recovery path

## Kill conditions
Stop or downgrade if purpose changes, sponsorship is hidden, data rights are unclear, the user is a child or vulnerable person, intent becomes high-impact, or the system is asked to act without human confirmation.
