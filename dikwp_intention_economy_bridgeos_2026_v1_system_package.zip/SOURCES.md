# Sources

- Chaudhary & Penn, Harvard Data Science Review / MIT Press, “Beware the Intention Economy: Collection and Commodification of Intent via Large Language Models”, 2024.
- University of Cambridge news release on the intention economy, 2024.
- NIST AI Risk Management Framework and GenAI Profile, 2023–2024.
- OpenAI public materials on ChatGPT agent and agentic commerce, 2025.
- WCAC 2026 Future Development Forecast Report provided by the user, 2026.
- DIKWP prior prototype reports emphasizing Evidence Ledger, Action Ticket, Human Review, Kill/Recovery, and Static Boundary Audit.

All scoring functions in this package are synthetic heuristics for learning and governance design. They are not legal, financial, advertising, procurement, or compliance determinations.
